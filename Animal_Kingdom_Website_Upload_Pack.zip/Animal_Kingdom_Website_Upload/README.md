# Animal Kingdom Web/PWA prototype

## Run it
Open `index.html` in a modern browser to play. For install/offline support, host the entire `web` folder on HTTPS. On Android Chrome, open the hosted URL and choose Install app or Add to Home screen.

## All three platforms roadmap
1. **Website/PWA:** included in this starter.
2. **Telegram Mini App:** host the PWA on HTTPS, create a bot via Telegram's official BotFather, configure its Mini App URL, then add Telegram WebApp integration and a server to validate users/referrals.
3. **Android APK:** wrap the hosted web app with a maintained Android packaging workflow or rebuild with a mobile framework; test on devices and comply with Play Store policies.

## Important prototype limits
This version is a client-side demo. Its leaderboard is local-only, referral rewards are not verified, and it has no accounts, backend/cloud saving, multiplayer, cryptocurrency, cash-outs, or real-money rewards. A production launch needs secure server-side validation, privacy policy, security testing, and platform review. Do not treat fictional game points as money.
